export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  iconName: string;
  capabilities: string[];
  materials: string[];
  typicalApplications: string[];
  image: string;
  featured?: boolean;
}

export type ProjectCategory = 'all' | 'fabrication' | 'structural' | 'maintenance' | 'oilgas';

export interface ProjectItem {
  id: string;
  title: string;
  category: ProjectCategory;
  categoryName: string;
  shortDesc: string;
  fullDesc: string;
  clientIndustry: string;
  location: string;
  completionYear: string;
  scopeOfWork: string[];
  keyDeliverables: string[];
  image: string;
  stats?: { label: string; value: string }[];
}

export interface QualityStandard {
  id: string;
  title: string;
  description: string;
  iconName: string;
  highlights: string[];
}

export interface WhyChooseUsItem {
  id: string;
  title: string;
  description: string;
  metric?: string;
  metricLabel?: string;
  iconName: string;
}

export interface CompanyInfo {
  name: string;
  tagline: string;
  address: string;
  city: string;
  state: string;
  country: string;
  phone: string;
  email: string;
  website: string;
  businessHours: string;
  establishedYear: number;
}

export interface InquiryFormState {
  name: string;
  companyName: string;
  email: string;
  phone: string;
  serviceId: string;
  projectLocation: string;
  timeline: string;
  estimatedBudget: string;
  message: string;
}

export interface SubmittedInquiry extends InquiryFormState {
  id: string;
  submittedAt: string;
  status: 'Pending Review' | 'Technical Scoping' | 'Quotation Sent';
}

export interface EstimatorInputs {
  serviceType: string;
  projectScale: 'small' | 'medium' | 'large' | 'heavy';
  materialGrade: 'carbon_steel' | 'stainless_steel' | 'alloy_steel' | 'custom';
  urgency: 'standard' | 'priority' | 'emergency';
  hasEngineeringDrawings: boolean;
  needsOnsiteInstallation: boolean;
}

export interface EstimatorResult {
  estimatedCostMin: number;
  estimatedCostMax: number;
  estimatedDurationWeeks: number;
  engineeringTeamSize: number;
  recommendedServices: string[];
}
