import React from 'react';
import {
  Award,
  ShieldCheck,
  Flame,
  ShieldAlert,
  Microscope,
  Leaf,
  CheckCircle2,
  FileCheck2,
  Download
} from 'lucide-react';
import { qualityStandardsData } from '../data/companyData';

export const QualitySafety: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Award': return <Award className="w-6 h-6 text-amber-400" />;
      case 'Flame': return <Flame className="w-6 h-6 text-amber-400" />;
      case 'ShieldAlert': return <ShieldAlert className="w-6 h-6 text-amber-400" />;
      case 'Microscope': return <Microscope className="w-6 h-6 text-amber-400" />;
      case 'Leaf': return <Leaf className="w-6 h-6 text-amber-400" />;
      default: return <ShieldCheck className="w-6 h-6 text-amber-400" />;
    }
  };

  return (
    <section id="quality-safety" className="py-20 bg-slate-900 border-t border-b border-slate-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest px-3.5 py-1 rounded-full">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>International Compliance</span>
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl font-extrabold text-white tracking-wide">
            Quality Assurance & Zero-Harm Safety Policy
          </h2>

          <p className="text-slate-400 text-base font-light">
            Quality and safety are non-negotiable foundations at ABC. Every weld, machine tolerance, and site erection procedure strictly adheres to ISO standards and ASME / AWS code requirements.
          </p>
        </div>

        {/* Grid of Standards */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {qualityStandardsData.map((item) => (
            <div
              key={item.id}
              className="bg-slate-950 border border-slate-800 hover:border-amber-500/40 p-7 rounded-2xl shadow-xl transition-all duration-300 space-y-4 hover:-translate-y-1"
            >
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
                {getIcon(item.iconName)}
              </div>

              <h3 className="font-heading text-xl font-bold text-white">
                {item.title}
              </h3>

              <p className="text-slate-300 text-sm leading-relaxed">
                {item.description}
              </p>

              <div className="pt-3 border-t border-slate-800/80 space-y-2">
                {item.highlights.map((h, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                    <span>{h}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* NDT Inspection & Certificate Download Bar */}
        <div className="mt-14 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-slate-800 p-8 rounded-2xl flex flex-col lg:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="space-y-2 text-center lg:text-left">
            <div className="inline-flex items-center gap-1.5 text-amber-400 text-xs font-bold uppercase tracking-wider">
              <FileCheck2 className="w-4 h-4" />
              <span>Full Technical Audit Documentation</span>
            </div>
            <h3 className="font-heading text-2xl font-bold text-white">
              Request Our Corporate EHS Policy & ISO Quality Manual
            </h3>
            <p className="text-slate-400 text-sm max-w-2xl">
              We provide complete Quality Assurance Plan (QAP) templates, Welding Procedure Specifications (WPS), and NDT test records upon vendor pre-qualification request.
            </p>
          </div>

          <a
            href={`mailto:${qualityStandardsData[0] ? 'info@abcengineering.com' : ''}?subject=Request%20Quality%20Manual%20and%20EHS%20Policy`}
            className="shrink-0 bg-slate-800 hover:bg-slate-700 text-white font-bold px-6 py-3.5 rounded-xl text-sm border border-slate-700 flex items-center gap-2 transition-colors"
          >
            <Download className="w-4 h-4 text-amber-400" />
            <span>Download Quality Overview (PDF)</span>
          </a>
        </div>

      </div>
    </section>
  );
};
