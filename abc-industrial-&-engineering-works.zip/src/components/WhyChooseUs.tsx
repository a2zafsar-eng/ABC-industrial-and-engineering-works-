import React from 'react';
import {
  Users,
  ShieldCheck,
  Clock,
  BadgeIndianRupee,
  Cpu,
  HardHat,
  CheckCircle,
  Award,
  Zap,
  TrendingUp
} from 'lucide-react';
import { whyChooseUsData } from '../data/companyData';

export const WhyChooseUs: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Users': return <Users className="w-6 h-6 text-amber-400" />;
      case 'ShieldCheck': return <ShieldCheck className="w-6 h-6 text-amber-400" />;
      case 'Clock': return <Clock className="w-6 h-6 text-amber-400" />;
      case 'BadgeIndianRupee': return <BadgeIndianRupee className="w-6 h-6 text-amber-400" />;
      case 'Cpu': return <Cpu className="w-6 h-6 text-amber-400" />;
      case 'HardHat': return <HardHat className="w-6 h-6 text-amber-400" />;
      default: return <Award className="w-6 h-6 text-amber-400" />;
    }
  };

  return (
    <section id="why-choose-us" className="py-20 bg-slate-950 relative overflow-hidden">
      
      {/* Background Decorative Element */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest px-3.5 py-1 rounded-full">
            <Award className="w-3.5 h-3.5" />
            <span>Operational Excellence</span>
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl font-extrabold text-white tracking-wide">
            Why Choose ABC Industrial & Engineering Works
          </h2>

          <p className="text-slate-400 text-base font-light">
            We combine decades of workshop expertise, certified engineering talent, and strict safety management to deliver high-precision industrial projects on time and within budget.
          </p>
        </div>

        {/* Pillars Grid */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {whyChooseUsData.map((item) => (
            <div
              key={item.id}
              className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-7 shadow-xl transition-all duration-300 hover:-translate-y-1 group relative overflow-hidden flex flex-col justify-between"
            >
              <div className="space-y-4">
                
                {/* Header row with Icon & Metric Badge */}
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors">
                    {getIcon(item.iconName)}
                  </div>

                  {item.metric && (
                    <div className="text-right">
                      <div className="font-heading text-xl font-extrabold text-amber-400">
                        {item.metric}
                      </div>
                      <div className="text-[10px] uppercase tracking-wider text-slate-400 font-medium">
                        {item.metricLabel}
                      </div>
                    </div>
                  )}
                </div>

                {/* Title */}
                <h3 className="font-heading text-xl font-bold text-white group-hover:text-amber-400 transition-colors">
                  {item.title}
                </h3>

                {/* Description */}
                <p className="text-slate-300 text-sm leading-relaxed">
                  {item.description}
                </p>

              </div>

              {/* Bottom decorative bar */}
              <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center gap-2 text-xs text-amber-400 font-semibold">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Verified Client Advantage</span>
              </div>
            </div>
          ))}
        </div>

        {/* Engineering Performance Bar */}
        <div className="mt-14 bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 grid grid-cols-2 lg:grid-cols-4 gap-6 text-center">
          <div>
            <div className="text-3xl font-extrabold text-white font-heading">100%</div>
            <div className="text-xs text-slate-400 uppercase tracking-wider mt-1">Raw Material Traceability</div>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-white font-heading">AWS D1.1</div>
            <div className="text-xs text-slate-400 uppercase tracking-wider mt-1">Structural Welding Code</div>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-white font-heading">±0.005mm</div>
            <div className="text-xs text-slate-400 uppercase tracking-wider mt-1">CNC Precision Tolerance</div>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-white font-heading">24/7</div>
            <div className="text-xs text-slate-400 uppercase tracking-wider mt-1">Shutdown Support Hotline</div>
          </div>
        </div>

      </div>
    </section>
  );
};
