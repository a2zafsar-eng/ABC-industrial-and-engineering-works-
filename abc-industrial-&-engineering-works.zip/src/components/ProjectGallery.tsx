import React, { useState } from 'react';
import {
  Briefcase,
  Eye,
  Building2,
  Calendar,
  MapPin,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Search,
  SlidersHorizontal
} from 'lucide-react';
import { projectsData } from '../data/companyData';
import { ProjectItem, ProjectCategory } from '../types';

interface ProjectGalleryProps {
  onSelectProject: (project: ProjectItem) => void;
  onRequestSimilar: (projectTitle: string) => void;
}

export const ProjectGallery: React.FC<ProjectGalleryProps> = ({
  onSelectProject,
  onRequestSimilar,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ProjectCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories: { id: ProjectCategory; label: string }[] = [
    { id: 'all', label: 'All Projects' },
    { id: 'fabrication', label: 'Industrial Fabrication' },
    { id: 'structural', label: 'Structural Steel' },
    { id: 'maintenance', label: 'Plant Maintenance' },
    { id: 'oilgas', label: 'Oil, Gas & Energy' },
  ];

  const filteredProjects = projectsData.filter((project) => {
    const matchesCategory = selectedCategory === 'all' || project.category === selectedCategory;
    const matchesSearch =
      project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.shortDesc.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.clientIndustry.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section id="projects" className="py-20 bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest px-3.5 py-1 rounded-full">
            <Briefcase className="w-3.5 h-3.5" />
            <span>Proven Track Record</span>
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl font-extrabold text-white tracking-wide">
            Industrial Project Gallery & Case Studies
          </h2>

          <p className="text-slate-400 text-base font-light">
            Explore a selection of our executed heavy fabrication, factory expansions, power plant maintenance turnarounds, and specialized oil & gas piping installations.
          </p>
        </div>

        {/* Category Filters & Search Bar */}
        <div className="mt-10 flex flex-col md:flex-row items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          
          {/* Category Pills */}
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search projects or sector..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-slate-200 placeholder-slate-500 text-xs rounded-xl pl-9 pr-3 py-2.5 focus:outline-none focus:border-amber-500"
            />
          </div>

        </div>

        {/* Gallery Grid */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="group bg-slate-900 border border-slate-800 hover:border-amber-500/50 rounded-2xl overflow-hidden shadow-xl transition-all duration-300 flex flex-col justify-between hover:-translate-y-1.5"
            >
              <div>
                {/* Image Container with Zoom & Overlay */}
                <div className="relative h-56 overflow-hidden bg-slate-950">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 filter brightness-90"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />

                  {/* Category Tag */}
                  <div className="absolute top-3 left-3 bg-slate-900/90 border border-slate-700 text-amber-400 text-[11px] font-bold px-2.5 py-1 rounded-md backdrop-blur-sm">
                    {project.categoryName}
                  </div>

                  <div className="absolute top-3 right-3 bg-slate-900/90 text-slate-300 text-[11px] font-semibold px-2.5 py-1 rounded-md backdrop-blur-sm flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-amber-500" />
                    <span>{project.completionYear}</span>
                  </div>

                  {/* Quick Preview Button Overlay */}
                  <button
                    onClick={() => onSelectProject(project)}
                    className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-slate-950/60 backdrop-blur-xs cursor-pointer"
                  >
                    <span className="bg-amber-500 text-slate-950 font-extrabold text-xs px-4 py-2 rounded-xl flex items-center gap-2 shadow-2xl transform translate-y-2 group-hover:translate-y-0 transition-transform">
                      <Eye className="w-4 h-4" />
                      <span>View Case Study</span>
                    </span>
                  </button>
                </div>

                {/* Card Content */}
                <div className="p-6 space-y-3">
                  <h3 className="font-heading text-xl font-bold text-white group-hover:text-amber-400 transition-colors">
                    {project.title}
                  </h3>

                  <p className="text-slate-300 text-xs leading-relaxed line-clamp-3">
                    {project.shortDesc}
                  </p>

                  <div className="flex items-center gap-2 text-xs text-slate-400 pt-1">
                    <MapPin className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span className="truncate">{project.location}</span>
                  </div>

                  {/* Project Metric Highlights */}
                  {project.stats && (
                    <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-800 text-center">
                      {project.stats.map((s, idx) => (
                        <div key={idx} className="bg-slate-950/80 p-1.5 rounded-lg border border-slate-800">
                          <div className="text-amber-400 font-bold text-xs font-heading">{s.value}</div>
                          <div className="text-[10px] text-slate-500 truncate">{s.label}</div>
                        </div>
                      ))}
                    </div>
                  )}

                </div>
              </div>

              {/* Card Footer */}
              <div className="p-6 pt-0 flex items-center gap-3">
                <button
                  onClick={() => onSelectProject(project)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 py-2.5 px-3 rounded-xl text-xs font-semibold border border-slate-700 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <span>Details</span>
                  <Eye className="w-3.5 h-3.5 text-amber-400" />
                </button>

                <button
                  onClick={() => onRequestSimilar(project.title)}
                  className="bg-amber-500/10 hover:bg-amber-500 text-amber-400 hover:text-slate-950 py-2.5 px-3 rounded-xl text-xs font-bold border border-amber-500/30 transition-all cursor-pointer flex items-center gap-1"
                  title="Request quote for a similar project"
                >
                  <span>Request Similar</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>
          ))}
        </div>

        {filteredProjects.length === 0 && (
          <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl mt-8 space-y-3">
            <Briefcase className="w-12 h-12 text-slate-600 mx-auto" />
            <h3 className="text-lg font-bold text-white">No Matching Projects Found</h3>
            <p className="text-slate-400 text-xs">Try adjusting your category filter or search keywords.</p>
            <button
              onClick={() => { setSelectedCategory('all'); setSearchQuery(''); }}
              className="bg-amber-500 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs"
            >
              Reset Filters
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
