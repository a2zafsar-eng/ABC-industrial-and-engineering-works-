import React from 'react';
import {
  X,
  ClipboardList,
  Clock,
  Building,
  CheckCircle2,
  Trash2,
  FileText
} from 'lucide-react';
import { SubmittedInquiry } from '../types';
import { servicesData } from '../data/companyData';

interface InquiryHistoryModalProps {
  inquiries: SubmittedInquiry[];
  isOpen: boolean;
  onClose: () => void;
  onClear: () => void;
}

export const InquiryHistoryModal: React.FC<InquiryHistoryModalProps> = ({
  inquiries,
  isOpen,
  onClose,
  onClear,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl relative max-h-[85vh] flex flex-col">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ClipboardList className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-heading text-xl font-bold text-white">
                My Submitted Quote Inquiries
              </h3>
              <p className="text-xs text-slate-400">
                Track status and review your submitted project specifications.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {inquiries.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <ClipboardList className="w-12 h-12 text-slate-700 mx-auto" />
              <div className="text-white font-bold text-base">No Inquiries Submitted Yet</div>
              <p className="text-slate-400 text-xs max-w-sm mx-auto">
                Use our Contact Form or Estimator tool to send your first project scope requirement.
              </p>
            </div>
          ) : (
            inquiries.map((inq) => {
              const serviceTitle = servicesData.find(s => s.id === inq.serviceId)?.title || inq.serviceId;
              return (
                <div key={inq.id} className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 text-xs">
                    <span className="font-mono font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded border border-amber-500/20">
                      {inq.id}
                    </span>
                    <span className="text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-500" />
                      {inq.submittedAt}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-slate-500">Contact: </span>
                      <span className="text-slate-200 font-semibold">{inq.name} ({inq.phone})</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Service: </span>
                      <span className="text-slate-200 font-semibold">{serviceTitle}</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Location: </span>
                      <span className="text-slate-200 font-semibold">{inq.projectLocation}</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Status: </span>
                      <span className="text-emerald-400 font-bold">{inq.status}</span>
                    </div>
                  </div>

                  {inq.message && (
                    <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-850 text-xs text-slate-300 whitespace-pre-line font-mono">
                      {inq.message}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-5 border-t border-slate-800 bg-slate-950 flex items-center justify-between shrink-0">
          {inquiries.length > 0 && (
            <button
              onClick={onClear}
              className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 hover:underline cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Inquiry History</span>
            </button>
          )}

          <button
            onClick={onClose}
            className="ml-auto bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-4 py-2 rounded-xl border border-slate-700 cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
