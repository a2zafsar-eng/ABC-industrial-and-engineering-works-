import React, { useState } from 'react';
import {
  Hammer,
  Building2,
  Cog,
  Cpu,
  Flame,
  Wrench,
  Truck,
  ClipboardCheck,
  ArrowRight,
  Check,
  ChevronRight,
  Layers,
  Sparkles
} from 'lucide-react';
import { servicesData } from '../data/companyData';
import { ServiceItem } from '../types';

interface ServicesSectionProps {
  onSelectService: (service: ServiceItem) => void;
  onInquireService: (serviceId: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onSelectService,
  onInquireService,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'featured' | 'machining'>('all');

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Hammer': return <Hammer className="w-6 h-6 text-amber-500" />;
      case 'Building2': return <Building2 className="w-6 h-6 text-amber-500" />;
      case 'Cog': return <Cog className="w-6 h-6 text-amber-500" />;
      case 'Cpu': return <Cpu className="w-6 h-6 text-amber-500" />;
      case 'Flame': return <Flame className="w-6 h-6 text-amber-500" />;
      case 'Wrench': return <Wrench className="w-6 h-6 text-amber-500" />;
      case 'Truck': return <Truck className="w-6 h-6 text-amber-500" />;
      case 'ClipboardCheck': return <ClipboardCheck className="w-6 h-6 text-amber-500" />;
      default: return <Wrench className="w-6 h-6 text-amber-500" />;
    }
  };

  const filteredServices = servicesData.filter((s) => {
    if (activeTab === 'featured') return s.featured;
    if (activeTab === 'machining') return s.id === 'cnc-machining' || s.id === 'mechanical-engineering' || s.id === 'welding-services';
    return true;
  });

  return (
    <section id="services" className="py-20 bg-slate-900 border-t border-b border-slate-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest px-3.5 py-1 rounded-full">
            <Layers className="w-3.5 h-3.5" />
            <span>Industrial Capabilities</span>
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl font-extrabold text-white tracking-wide">
            Comprehensive Industrial & Engineering Services
          </h2>

          <p className="text-slate-400 text-base font-light">
            From heavy structural steel fabrication and high-precision CNC machining to site equipment erection and plant maintenance, ABC delivers turnkey engineering solutions tailored to your operational requirements.
          </p>

          {/* Filter Tabs */}
          <div className="pt-4 flex justify-center gap-2">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              All Services ({servicesData.length})
            </button>
            <button
              onClick={() => setActiveTab('featured')}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                activeTab === 'featured'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Core Flagships
            </button>
            <button
              onClick={() => setActiveTab('machining')}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                activeTab === 'machining'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Machining & Welding
            </button>
          </div>
        </div>

        {/* Services Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="group bg-slate-950 border border-slate-800 hover:border-amber-500/50 rounded-2xl overflow-hidden shadow-xl transition-all duration-300 flex flex-col justify-between hover:-translate-y-1"
            >
              <div>
                {/* Service Image Banner */}
                <div className="relative h-48 overflow-hidden bg-slate-900">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-90"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                  
                  {/* Icon Badge */}
                  <div className="absolute bottom-3 left-4 w-12 h-12 rounded-xl bg-slate-900/90 border border-slate-700 flex items-center justify-center shadow-lg backdrop-blur-sm">
                    {getIcon(service.iconName)}
                  </div>

                  {service.featured && (
                    <div className="absolute top-3 right-3 bg-amber-500 text-slate-950 text-[11px] font-extrabold uppercase px-2.5 py-0.5 rounded-md tracking-wider">
                      Flagship
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                  <h3 className="font-heading text-xl font-bold text-white group-hover:text-amber-400 transition-colors">
                    {service.title}
                  </h3>

                  <p className="text-slate-300 text-sm leading-relaxed line-clamp-3">
                    {service.shortDesc}
                  </p>

                  {/* Highlights checklist */}
                  <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                    <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                      Key Capabilities:
                    </div>
                    {service.capabilities.slice(0, 3).map((cap, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                        <span className="line-clamp-1">{cap}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="px-6 pb-6 pt-2 flex items-center gap-3">
                <button
                  onClick={() => onSelectService(service)}
                  className="flex-1 bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white py-2.5 px-3 rounded-lg text-xs font-semibold border border-slate-700 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <span>Full Specs</span>
                  <ChevronRight className="w-3.5 h-3.5 text-amber-400" />
                </button>

                <button
                  onClick={() => onInquireService(service.id)}
                  className="bg-amber-500 hover:bg-amber-400 text-slate-950 py-2.5 px-3 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 shadow-md"
                  title="Request quote for this service"
                >
                  <span>Inquire</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>
          ))}
        </div>

        {/* Bottom Banner for Custom Scope */}
        <div className="mt-16 bg-gradient-to-r from-amber-500/10 via-slate-900 to-amber-500/10 border border-amber-500/30 rounded-2xl p-8 text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1">
            <h3 className="font-heading text-2xl font-bold text-white flex items-center gap-2 justify-center sm:justify-start">
              <Sparkles className="w-5 h-5 text-amber-400" />
              Need a Custom Fabricated Assembly or Onsite Scope?
            </h3>
            <p className="text-slate-300 text-sm">
              Our engineering team reviews custom CAD drawings, BOQ sheets, and tailored site specs within 24 hours.
            </p>
          </div>

          <button
            onClick={() => onInquireService('custom')}
            className="shrink-0 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold px-6 py-3 rounded-xl text-sm shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
          >
            Submit Engineering Drawings
          </button>
        </div>

      </div>
    </section>
  );
};
