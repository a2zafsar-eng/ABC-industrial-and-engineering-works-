import React from 'react';
import {
  X,
  Building2,
  Calendar,
  MapPin,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Award
} from 'lucide-react';
import { ProjectItem } from '../types';

interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
  onRequestSimilar: (title: string) => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({
  project,
  onClose,
  onRequestSimilar,
}) => {
  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl relative max-h-[90vh] flex flex-col">
        
        {/* Header Image */}
        <div className="relative h-60 bg-slate-950 shrink-0">
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover filter brightness-90"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-slate-950/80 hover:bg-slate-950 text-slate-300 hover:text-white p-2 rounded-full border border-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-4 left-6 right-6 space-y-1">
            <div className="flex items-center gap-2">
              <span className="bg-amber-500 text-slate-950 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-md tracking-wider">
                {project.categoryName}
              </span>
              <span className="text-slate-300 text-xs flex items-center gap-1 font-semibold">
                <Calendar className="w-3.5 h-3.5 text-amber-500" />
                {project.completionYear}
              </span>
            </div>

            <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-white">
              {project.title}
            </h2>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm">
          
          {/* Metadata Row */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs">
            <div>
              <div className="text-slate-400">Client Sector:</div>
              <div className="font-bold text-white mt-0.5">{project.clientIndustry}</div>
            </div>
            <div>
              <div className="text-slate-400">Location:</div>
              <div className="font-bold text-white mt-0.5 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-amber-500 shrink-0" />
                <span>{project.location}</span>
              </div>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <div className="text-slate-400">Status:</div>
              <div className="font-bold text-emerald-400 mt-0.5">100% Handed Over</div>
            </div>
          </div>

          <p className="text-slate-300 leading-relaxed">
            {project.fullDesc}
          </p>

          {/* Scope of Work */}
          <div className="space-y-2">
            <h3 className="font-heading text-lg font-bold text-white">
              Scope of Engineering Work
            </h3>
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              {project.scopeOfWork.map((item, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Key Deliverables & Outcomes */}
          <div className="space-y-2">
            <h3 className="font-heading text-lg font-bold text-white">
              Project Outcomes & Client Highlights
            </h3>
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              {project.keyDeliverables.map((item, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                  <Award className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-5 border-t border-slate-800 bg-slate-950 flex items-center justify-between gap-4 shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-white bg-slate-900 border border-slate-800 transition-colors"
          >
            Close
          </button>

          <button
            onClick={() => {
              onRequestSimilar(project.title);
              onClose();
            }}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold px-5 py-2.5 rounded-xl text-xs shadow-lg flex items-center gap-2 transition-all"
          >
            <span>Request Similar Project Quote</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
