import React from 'react';
import {
  X,
  CheckCircle2,
  Layers,
  Wrench,
  Cpu,
  ArrowRight,
  ShieldCheck,
  Building2,
  Hammer
} from 'lucide-react';
import { ServiceItem } from '../types';

interface ServiceModalProps {
  service: ServiceItem | null;
  onClose: () => void;
  onInquire: (serviceId: string) => void;
}

export const ServiceModal: React.FC<ServiceModalProps> = ({
  service,
  onClose,
  onInquire,
}) => {
  if (!service) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl relative max-h-[90vh] flex flex-col">
        
        {/* Header Image */}
        <div className="relative h-52 bg-slate-950 shrink-0">
          <img
            src={service.image}
            alt={service.title}
            className="w-full h-full object-cover filter brightness-90"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-slate-950/80 hover:bg-slate-950 text-slate-300 hover:text-white p-2 rounded-full border border-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-4 left-6 right-6">
            <div className="inline-flex items-center gap-1.5 bg-amber-500 text-slate-950 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-md tracking-wider mb-1">
              Industrial Capability Spec
            </div>
            <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-white">
              {service.title}
            </h2>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm">
          
          <p className="text-slate-300 leading-relaxed">
            {service.fullDesc}
          </p>

          {/* Key Capabilities */}
          <div className="space-y-2">
            <h3 className="font-heading text-lg font-bold text-white flex items-center gap-2">
              <Wrench className="w-4 h-4 text-amber-500" />
              Technical Capabilities & Scope
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-950 p-4 rounded-xl border border-slate-800">
              {service.capabilities.map((cap, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                  <span>{cap}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Materials & Applications */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <h4 className="font-bold text-amber-400 uppercase tracking-wider">
                Materials Processed
              </h4>
              <ul className="space-y-1 text-slate-300 list-disc list-inside">
                {service.materials.map((m, i) => (
                  <li key={i}>{m}</li>
                ))}
              </ul>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <h4 className="font-bold text-amber-400 uppercase tracking-wider">
                Target Industries
              </h4>
              <ul className="space-y-1 text-slate-300 list-disc list-inside">
                {service.typicalApplications.map((app, i) => (
                  <li key={i}>{app}</li>
                ))}
              </ul>
            </div>

          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-5 border-t border-slate-800 bg-slate-950 flex items-center justify-between gap-4 shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-white bg-slate-900 border border-slate-800 transition-colors"
          >
            Close Window
          </button>

          <button
            onClick={() => {
              onInquire(service.id);
              onClose();
            }}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold px-5 py-2.5 rounded-xl text-xs shadow-lg flex items-center gap-2 transition-all"
          >
            <span>Inquire For This Service</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
