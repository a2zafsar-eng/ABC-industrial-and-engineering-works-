import React from 'react';
import {
  ArrowRight,
  ShieldCheck,
  Award,
  CheckCircle2,
  Calculator,
  Building2,
  Wrench,
  Factory,
  Flame
} from 'lucide-react';
import { heroData, companyDetails } from '../data/companyData';

interface HeroSectionProps {
  onNavigate: (sectionId: string) => void;
  onOpenEstimator: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onNavigate,
  onOpenEstimator,
}) => {
  return (
    <section id="home" className="relative pt-28 pb-16 lg:pt-36 lg:pb-24 overflow-hidden bg-slate-950">
      {/* Background Image Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroData.bgImage}
          alt="ABC Industrial Engineering Fabrication"
          className="w-full h-full object-cover object-center opacity-25 scale-105 filter contrast-125"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/90 to-slate-950/70" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950/60" />
        
        {/* Subtle Engineering Grid Overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:4rem_4rem]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main Hero Copy */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Trust Pill */}
            <div className="inline-flex items-center gap-2 bg-slate-900/90 border border-amber-500/30 rounded-full px-3.5 py-1.5 text-xs text-amber-400 font-semibold shadow-inner">
              <ShieldCheck className="w-4 h-4 text-amber-500" />
              <span>Certified Industrial Fabrication & Machinery Partner</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-heading text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white leading-tight tracking-wide">
              Precision Engineering Solutions for <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-500 to-amber-200">Modern Industries</span>
            </h1>

            {/* Description */}
            <p className="text-slate-300 text-base sm:text-lg leading-relaxed max-w-2xl font-light">
              {heroData.subheadline}
            </p>

            {/* CTA Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={() => onNavigate('contact')}
                className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold px-6 py-3.5 rounded-xl text-base shadow-lg shadow-amber-500/25 transition-all cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>Request a Project Quote</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              <button
                onClick={() => onNavigate('projects')}
                className="flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white font-semibold px-5 py-3.5 rounded-xl text-base border border-slate-700/80 transition-all cursor-pointer"
              >
                <Building2 className="w-4 h-4 text-amber-400" />
                <span>View Project Gallery</span>
              </button>

              <button
                onClick={onOpenEstimator}
                className="flex items-center gap-2 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 font-semibold px-4 py-3.5 rounded-xl text-sm border border-amber-500/30 transition-all cursor-pointer"
              >
                <Calculator className="w-4 h-4 text-amber-400" />
                <span>Calculate Estimate</span>
              </button>
            </div>

            {/* Fast Features Bar */}
            <div className="pt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-slate-400 border-t border-slate-800/80">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                <span>ISO 9001 Process</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Certified Welders</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Precision CNC Tech</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Safety Compliant</span>
              </div>
            </div>

          </div>

          {/* Stat Cards & Feature Highlights Sidebar */}
          <div className="lg:col-span-5 space-y-4">
            
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl backdrop-blur-md relative">
              <div className="absolute -top-3 right-6 bg-amber-500 text-slate-950 text-xs font-bold px-3 py-0.5 rounded-full uppercase tracking-wider">
                Industrial Excellence
              </div>

              <h3 className="font-heading text-xl font-bold text-white mb-4 flex items-center gap-2">
                <Factory className="w-5 h-5 text-amber-500" />
                Why Clients Trust ABC
              </h3>

              <div className="grid grid-cols-2 gap-4">
                {heroData.stats.map((stat, index) => (
                  <div key={index} className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl">
                    <div className="font-heading text-2xl sm:text-3xl font-extrabold text-amber-400">
                      {stat.value}
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5 font-medium">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>

              {/* Quick Contact Banner */}
              <div className="mt-5 p-3.5 bg-gradient-to-r from-slate-950 to-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-400">Need Urgent Plant Support?</div>
                  <div className="text-sm font-bold text-white flex items-center gap-1.5 mt-0.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span>{companyDetails.phone}</span>
                  </div>
                </div>
                <button
                  onClick={() => onNavigate('contact')}
                  className="bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
                >
                  Contact Us
                </button>
              </div>
            </div>

            {/* Quick Capability Tags */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
              <span className="font-semibold text-slate-300">Core Disciplines:</span>
              <span className="bg-slate-800 text-slate-300 px-2.5 py-1 rounded-md">Heavy Steel</span>
              <span className="bg-slate-800 text-slate-300 px-2.5 py-1 rounded-md">CNC Milling</span>
              <span className="bg-slate-800 text-slate-300 px-2.5 py-1 rounded-md">TIG/MIG Welding</span>
              <span className="bg-slate-800 text-slate-300 px-2.5 py-1 rounded-md">Piping & Tanks</span>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
