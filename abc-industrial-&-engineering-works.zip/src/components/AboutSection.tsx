import React, { useState } from 'react';
import {
  Building,
  Target,
  Compass,
  CheckCircle,
  Factory,
  Zap,
  Flame,
  Truck,
  ShieldCheck,
  Calendar,
  Users
} from 'lucide-react';
import { aboutData, companyDetails } from '../data/companyData';

export const AboutSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'mission' | 'vision' | 'story'>('story');

  return (
    <section id="about" className="py-20 bg-slate-900 border-t border-b border-slate-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Story & Vision */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest px-3.5 py-1 rounded-full">
              <Building className="w-3.5 h-3.5" />
              <span>About Our Company</span>
            </div>

            <h2 className="font-heading text-3xl sm:text-4xl font-extrabold text-white tracking-wide">
              Pioneering Engineering & Industrial Excellence
            </h2>

            <p className="text-slate-300 text-base sm:text-lg leading-relaxed font-light">
              {aboutData.overview}
            </p>

            {/* Interactive Tab Switcher for Story / Mission / Vision */}
            <div className="pt-2">
              <div className="flex gap-2 border-b border-slate-800 pb-3">
                <button
                  onClick={() => setActiveTab('story')}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                    activeTab === 'story'
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'text-slate-400 hover:text-white bg-slate-800'
                  }`}
                >
                  Company Overview
                </button>
                <button
                  onClick={() => setActiveTab('mission')}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                    activeTab === 'mission'
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'text-slate-400 hover:text-white bg-slate-800'
                  }`}
                >
                  Our Mission
                </button>
                <button
                  onClick={() => setActiveTab('vision')}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                    activeTab === 'vision'
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'text-slate-400 hover:text-white bg-slate-800'
                  }`}
                >
                  Our Vision
                </button>
              </div>

              <div className="pt-4 bg-slate-950/60 border border-slate-800/80 rounded-xl p-5 mt-2 min-h-[120px]">
                {activeTab === 'story' && (
                  <div className="space-y-3">
                    <p className="text-slate-300 text-sm leading-relaxed">
                      Founded in Bangalore, <strong className="text-white">ABC Industrial & Engineering Works</strong> has grown into a premier multi-disciplinary fabrication, machining, and engineering partner. We serve manufacturing plants, infrastructure contractors, energy producers, and oil & gas facilities across South India.
                    </p>
                    <div className="flex items-center gap-6 text-xs text-amber-400 font-semibold pt-1">
                      <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> Est. {companyDetails.establishedYear}</span>
                      <span className="flex items-center gap-1.5"><Users className="w-3.5 h-3.5" /> 75+ Skilled Technicians</span>
                      <span className="flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5" /> ISO 9001 Facility</span>
                    </div>
                  </div>
                )}

                {activeTab === 'mission' && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 font-heading font-bold text-amber-400 text-lg">
                      <Target className="w-5 h-5" />
                      Mission Statement
                    </div>
                    <p className="text-slate-200 text-base leading-relaxed italic font-serif">
                      "{aboutData.mission}"
                    </p>
                  </div>
                )}

                {activeTab === 'vision' && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 font-heading font-bold text-amber-400 text-lg">
                      <Compass className="w-5 h-5" />
                      Vision Statement
                    </div>
                    <p className="text-slate-200 text-base leading-relaxed italic font-serif">
                      "{aboutData.vision}"
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Core Values Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {aboutData.values.map((val, idx) => (
                <div key={idx} className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-1">
                  <div className="text-amber-400 font-heading font-bold text-base flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-amber-500" />
                    {val.title}
                  </div>
                  <p className="text-slate-400 text-xs leading-relaxed">
                    {val.desc}
                  </p>
                </div>
              ))}
            </div>

          </div>

          {/* Right Column: Key Sectors Served */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
              <div className="absolute -top-12 -right-12 w-32 h-32 bg-amber-500/10 rounded-full blur-xl pointer-events-none" />

              <h3 className="font-heading text-2xl font-bold text-white mb-6 flex items-center gap-2">
                <Factory className="w-6 h-6 text-amber-500" />
                Industries We Serve
              </h3>

              <div className="space-y-4">
                {aboutData.sectorsServed.map((sector, i) => (
                  <div key={i} className="bg-slate-900 border border-slate-800 p-4 rounded-xl hover:border-amber-500/40 transition-colors">
                    <div className="text-sm font-bold text-amber-400 font-heading">
                      {sector.name}
                    </div>
                    <div className="text-xs text-slate-300 mt-1">
                      {sector.desc}
                    </div>
                  </div>
                ))}
              </div>

              {/* Callout */}
              <div className="mt-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl text-xs text-amber-300 leading-relaxed font-medium">
                ⚡ Need custom pre-qualification documents or vendor registration details for your company? Contact our corporate desk today.
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
