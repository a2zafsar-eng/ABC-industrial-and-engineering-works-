import React, { useState, useEffect } from 'react';
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Globe,
  Send,
  CheckCircle,
  Copy,
  ExternalLink,
  Upload,
  Sparkles,
  Building,
  FileText,
  AlertCircle
} from 'lucide-react';
import { companyDetails, servicesData } from '../data/companyData';
import { InquiryFormState, SubmittedInquiry } from '../types';

interface ContactSectionProps {
  initialServiceId?: string;
  initialBudgetText?: string;
  initialMessageText?: string;
  onInquirySubmitted: (inquiry: SubmittedInquiry) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  initialServiceId = 'industrial-fabrication',
  initialBudgetText = '',
  initialMessageText = '',
  onInquirySubmitted,
}) => {
  const [formData, setFormData] = useState<InquiryFormState>({
    name: '',
    companyName: '',
    email: '',
    phone: '',
    serviceId: initialServiceId,
    projectLocation: 'Bangalore, Karnataka',
    timeline: 'Within 1 Month',
    estimatedBudget: initialBudgetText,
    message: initialMessageText,
  });

  const [copiedAddress, setCopiedAddress] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submittedInquiry, setSubmittedInquiry] = useState<SubmittedInquiry | null>(null);
  const [attachedFileName, setAttachedFileName] = useState<string | null>(null);

  useEffect(() => {
    if (initialServiceId) {
      setFormData(prev => ({ ...prev, serviceId: initialServiceId }));
    }
  }, [initialServiceId]);

  useEffect(() => {
    if (initialBudgetText || initialMessageText) {
      setFormData(prev => ({
        ...prev,
        estimatedBudget: initialBudgetText || prev.estimatedBudget,
        message: initialMessageText || prev.message,
      }));
    }
  }, [initialBudgetText, initialMessageText]);

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(`${companyDetails.name}, ${companyDetails.address}`);
    setCopiedAddress(true);
    setTimeout(() => setCopiedAddress(false), 2000);
  };

  const handleFileUploadSim = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setAttachedFileName(e.target.files[0].name);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    setTimeout(() => {
      const newInquiry: SubmittedInquiry = {
        ...formData,
        id: `ABC-INQ-${Math.floor(100000 + Math.random() * 900000)}`,
        submittedAt: new Date().toLocaleString(),
        status: 'Pending Review',
      };

      setSubmittedInquiry(newInquiry);
      onInquirySubmitted(newInquiry);
      setSubmitting(false);
    }, 1000);
  };

  const handleResetForm = () => {
    setSubmittedInquiry(null);
    setAttachedFileName(null);
    setFormData({
      name: '',
      companyName: '',
      email: '',
      phone: '',
      serviceId: 'industrial-fabrication',
      projectLocation: 'Bangalore, Karnataka',
      timeline: 'Within 1 Month',
      estimatedBudget: '',
      message: '',
    });
  };

  return (
    <section id="contact" className="py-20 bg-slate-950 border-t border-slate-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest px-3.5 py-1 rounded-full">
            <Mail className="w-3.5 h-3.5" />
            <span>Connect With Our Engineering Team</span>
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl font-extrabold text-white tracking-wide">
            Contact Us & Request a Project Quote
          </h2>

          <p className="text-slate-400 text-base font-light">
            Have a new fabrication project, structural steel inquiry, or plant maintenance requirement? Reach out to ABC Industrial & Engineering Works today.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: Official Contact Details */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
              
              <div className="border-b border-slate-800 pb-4">
                <h3 className="font-heading text-2xl font-bold text-white">
                  {companyDetails.name}
                </h3>
                <p className="text-xs text-amber-400 font-semibold mt-1">
                  {companyDetails.tagline}
                </p>
              </div>

              <div className="space-y-4 text-sm">
                
                {/* Address */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center shrink-0 text-amber-400">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-medium">Headquarters & Workshop:</div>
                    <div className="text-slate-200 font-semibold mt-0.5">{companyDetails.address}</div>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center shrink-0 text-amber-400">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-medium">Direct Phone / Hotline:</div>
                    <a href={`tel:${companyDetails.phone}`} className="text-amber-400 font-bold hover:underline mt-0.5 block">
                      {companyDetails.phone}
                    </a>
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center shrink-0 text-amber-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-medium">Official Inquiry Email:</div>
                    <a href={`mailto:${companyDetails.email}`} className="text-amber-400 font-bold hover:underline mt-0.5 block">
                      {companyDetails.email}
                    </a>
                  </div>
                </div>

                {/* Website */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center shrink-0 text-amber-400">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-medium">Web Portal:</div>
                    <div className="text-slate-200 font-semibold mt-0.5">{companyDetails.website}</div>
                  </div>
                </div>

                {/* Hours */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center shrink-0 text-amber-400">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-medium">Business Working Hours:</div>
                    <div className="text-slate-200 font-semibold mt-0.5">{companyDetails.businessHours}</div>
                  </div>
                </div>

              </div>

              {/* Copy Address Action */}
              <div className="pt-4 border-t border-slate-800 flex items-center gap-3">
                <button
                  onClick={handleCopyAddress}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 py-2.5 px-3 rounded-xl text-xs font-semibold border border-slate-700 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5 text-amber-400" />
                  <span>{copiedAddress ? 'Address Copied!' : 'Copy Full Address'}</span>
                </button>
              </div>

            </div>

            {/* Interactive Location Map Simulation */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 overflow-hidden space-y-3">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                <span className="flex items-center gap-1.5 text-amber-400">
                  <MapPin className="w-4 h-4" />
                  Industrial Area, Bangalore
                </span>
                <span className="text-slate-500">Karnataka, India</span>
              </div>

              <div className="relative h-44 rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center group">
                <img
                  src="https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&q=80&w=800"
                  alt="Bangalore Map Representation"
                  className="w-full h-full object-cover filter brightness-50 opacity-60 group-hover:scale-105 transition-transform"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />

                <div className="absolute bg-slate-900/90 border border-amber-500/50 p-3 rounded-xl shadow-2xl text-center space-y-1 backdrop-blur-md">
                  <div className="w-3 h-3 rounded-full bg-amber-500 mx-auto animate-ping" />
                  <div className="text-xs font-extrabold text-white">ABC Workshop Facility</div>
                  <div className="text-[10px] text-slate-400">Bangalore Industrial Corridor</div>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Quote & Contact Form */}
          <div className="lg:col-span-7">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
              
              {submittedInquiry ? (
                /* Success State */
                <div className="py-8 text-center space-y-6">
                  <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto shadow-xl">
                    <CheckCircle className="w-8 h-8" />
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-heading text-2xl font-bold text-white">
                      Inquiry Successfully Received!
                    </h3>
                    <p className="text-slate-300 text-sm max-w-md mx-auto">
                      Thank you for contacting ABC Industrial & Engineering Works. Our engineering estimation department is reviewing your specifications.
                    </p>
                  </div>

                  {/* Summary Box */}
                  <div className="bg-slate-950 border border-slate-800 p-5 rounded-2xl text-left text-xs space-y-2 max-w-md mx-auto">
                    <div className="flex justify-between border-b border-slate-800 pb-2">
                      <span className="text-slate-400">Reference ID:</span>
                      <span className="font-bold text-amber-400">{submittedInquiry.id}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-800 pb-2">
                      <span className="text-slate-400">Client / Company:</span>
                      <span className="font-semibold text-white">{submittedInquiry.name} ({submittedInquiry.companyName || 'Individual'})</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-800 pb-2">
                      <span className="text-slate-400">Service Required:</span>
                      <span className="font-semibold text-white">{servicesData.find(s => s.id === submittedInquiry.serviceId)?.title || submittedInquiry.serviceId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Status:</span>
                      <span className="font-semibold text-emerald-400">{submittedInquiry.status}</span>
                    </div>
                  </div>

                  <div className="pt-2 flex flex-col sm:flex-row justify-center gap-3">
                    <button
                      onClick={handleResetForm}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold px-5 py-2.5 rounded-xl text-xs border border-slate-700 transition-colors"
                    >
                      Submit Another Request
                    </button>
                  </div>

                </div>
              ) : (
                /* Form */
                <form onSubmit={handleSubmit} className="space-y-5">
                  
                  <div className="border-b border-slate-800 pb-4">
                    <h3 className="font-heading text-2xl font-bold text-white flex items-center gap-2">
                      <FileText className="w-5 h-5 text-amber-500" />
                      Project Inquiry & RFQ Form
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Fill in your requirements below for a detailed technical proposal and budgetary estimate.
                    </p>
                  </div>

                  {/* Name & Company */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">
                        Full Name <span className="text-amber-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g., Rajesh Kumar"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">
                        Company / Firm Name
                      </label>
                      <input
                        type="text"
                        placeholder="e.g., Apex Heavy Industries Ltd."
                        value={formData.companyName}
                        onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* Email & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">
                        Email Address <span className="text-amber-500">*</span>
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="e.g., rajesh@apex.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">
                        Phone Number <span className="text-amber-500">*</span>
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="e.g., +91 98765 43210"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* Service Selector & Location */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">
                        Service Category Required
                      </label>
                      <select
                        value={formData.serviceId}
                        onChange={(e) => setFormData({ ...formData, serviceId: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500"
                      >
                        {servicesData.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.title}
                          </option>
                        ))}
                        <option value="custom">Custom Turnkey Engineering</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">
                        Project Site Location
                      </label>
                      <input
                        type="text"
                        placeholder="e.g., Peenya Industrial Area, Bangalore"
                        value={formData.projectLocation}
                        onChange={(e) => setFormData({ ...formData, projectLocation: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* Budget & Timeline */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">
                        Estimated Budget (Optional)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g., ₹2,50,000 - ₹5,00,000"
                        value={formData.estimatedBudget}
                        onChange={(e) => setFormData({ ...formData, estimatedBudget: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">
                        Expected Execution Timeline
                      </label>
                      <select
                        value={formData.timeline}
                        onChange={(e) => setFormData({ ...formData, timeline: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500"
                      >
                        <option value="Immediate Emergency">Immediate / Plant Shutdown</option>
                        <option value="Within 1 Month">Within 1 Month</option>
                        <option value="1 to 3 Months">1 to 3 Months</option>
                        <option value="Planning Phase">Long-term Planning / Tender</option>
                      </select>
                    </div>
                  </div>

                  {/* Message */}
                  <div className="text-xs">
                    <label className="block text-slate-300 font-semibold mb-1">
                      Project Specifications / Message Details <span className="text-amber-500">*</span>
                    </label>
                    <textarea
                      required
                      rows={4}
                      placeholder="Specify material grades, dimensions, tonnage, drawing references, or site access constraints..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  {/* File Attachment Simulation */}
                  <div className="text-xs bg-slate-950 border border-slate-800 p-3.5 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-2 text-slate-400">
                      <Upload className="w-4 h-4 text-amber-500 shrink-0" />
                      <span className="truncate">
                        {attachedFileName ? `Attached: ${attachedFileName}` : 'Attach CAD Drawing / BOQ (PDF, DWG, ZIP)'}
                      </span>
                    </div>

                    <label className="bg-slate-800 hover:bg-slate-700 text-amber-400 px-3 py-1.5 rounded-lg border border-slate-700 cursor-pointer font-semibold transition-colors shrink-0">
                      Browse File
                      <input
                        type="file"
                        className="hidden"
                        onChange={handleFileUploadSim}
                      />
                    </label>
                  </div>

                  {/* Submit CTA */}
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold py-3.5 px-6 rounded-xl text-sm shadow-xl shadow-amber-500/20 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    {submitting ? (
                      <span>Processing Request...</span>
                    ) : (
                      <>
                        <span>Submit Project RFQ</span>
                        <Send className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <p className="text-[11px] text-slate-500 text-center">
                    🔒 ABC guarantees strict NDA confidentiality for all proprietary engineering drawings and commercial terms.
                  </p>

                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
