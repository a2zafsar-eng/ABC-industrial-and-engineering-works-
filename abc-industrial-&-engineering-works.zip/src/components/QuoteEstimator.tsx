import React, { useState } from 'react';
import {
  Calculator,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  Clock,
  IndianRupee,
  Users,
  ShieldCheck,
  RefreshCw,
  Send
} from 'lucide-react';
import { EstimatorInputs, EstimatorResult } from '../types';

interface QuoteEstimatorProps {
  onApplyEstimate: (serviceId: string, budgetText: string, messageText: string) => void;
}

export const QuoteEstimator: React.FC<QuoteEstimatorProps> = ({ onApplyEstimate }) => {
  const [inputs, setInputs] = useState<EstimatorInputs>({
    serviceType: 'industrial-fabrication',
    projectScale: 'medium',
    materialGrade: 'carbon_steel',
    urgency: 'standard',
    hasEngineeringDrawings: true,
    needsOnsiteInstallation: true,
  });

  const calculateEstimate = (): EstimatorResult => {
    let baseMin = 150000;
    let baseMax = 350000;
    let durationWeeks = 2;
    let teamSize = 4;

    // Service Type Multiplier
    switch (inputs.serviceType) {
      case 'industrial-fabrication':
        baseMin = 250000;
        baseMax = 600000;
        durationWeeks = 3;
        teamSize = 6;
        break;
      case 'structural-engineering':
        baseMin = 500000;
        baseMax = 1800000;
        durationWeeks = 6;
        teamSize = 12;
        break;
      case 'cnc-machining':
        baseMin = 80000;
        baseMax = 250000;
        durationWeeks = 2;
        teamSize = 3;
        break;
      case 'plant-maintenance':
        baseMin = 180000;
        baseMax = 500000;
        durationWeeks = 1.5;
        teamSize = 8;
        break;
      case 'equipment-installation':
        baseMin = 200000;
        baseMax = 700000;
        durationWeeks = 2.5;
        teamSize = 7;
        break;
      default:
        break;
    }

    // Scale
    if (inputs.projectScale === 'small') {
      baseMin *= 0.5;
      baseMax *= 0.6;
      durationWeeks *= 0.6;
      teamSize = Math.max(2, Math.floor(teamSize * 0.6));
    } else if (inputs.projectScale === 'large') {
      baseMin *= 2.2;
      baseMax *= 2.5;
      durationWeeks *= 1.8;
      teamSize = Math.floor(teamSize * 1.8);
    } else if (inputs.projectScale === 'heavy') {
      baseMin *= 4.5;
      baseMax *= 5.0;
      durationWeeks *= 2.5;
      teamSize = Math.floor(teamSize * 2.5);
    }

    // Material
    if (inputs.materialGrade === 'stainless_steel') {
      baseMin *= 1.6;
      baseMax *= 1.7;
    } else if (inputs.materialGrade === 'alloy_steel') {
      baseMin *= 1.8;
      baseMax *= 1.9;
    }

    // Urgency
    if (inputs.urgency === 'priority') {
      baseMin *= 1.15;
      baseMax *= 1.2;
      durationWeeks = Math.max(1, Math.round(durationWeeks * 0.7));
    } else if (inputs.urgency === 'emergency') {
      baseMin *= 1.35;
      baseMax *= 1.4;
      durationWeeks = Math.max(0.5, Math.round(durationWeeks * 0.5));
    }

    // Onsite Installation
    if (inputs.needsOnsiteInstallation) {
      baseMin += 40000;
      baseMax += 90000;
    }

    // Drawings discount
    if (!inputs.hasEngineeringDrawings) {
      baseMin += 25000; // Cad modeling fee
      baseMax += 45000;
    }

    return {
      estimatedCostMin: Math.round(baseMin),
      estimatedCostMax: Math.round(baseMax),
      estimatedDurationWeeks: Math.max(0.5, Math.round(durationWeeks * 10) / 10),
      engineeringTeamSize: teamSize,
      recommendedServices: [
        '3D CAD Detailing',
        'ISO Quality Inspection',
        inputs.needsOnsiteInstallation ? 'Onsite Rigging & Erection' : 'Factory Pre-Assembly Test',
      ]
    };
  };

  const result = calculateEstimate();

  const formatRupees = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const handleApplyToContact = () => {
    const budgetText = `${formatRupees(result.estimatedCostMin)} - ${formatRupees(result.estimatedCostMax)}`;
    const messageText = `Project Estimate Generated:
- Service: ${inputs.serviceType}
- Scale: ${inputs.projectScale}
- Material: ${inputs.materialGrade}
- Urgency: ${inputs.urgency}
- Onsite Work: ${inputs.needsOnsiteInstallation ? 'Yes' : 'No'}
- CAD Drawings: ${inputs.hasEngineeringDrawings ? 'Available' : 'Needs Drafting'}
- Estimated Timeline: ${result.estimatedDurationWeeks} Weeks`;

    onApplyEstimate(inputs.serviceType, budgetText, messageText);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-heading text-xl font-bold text-white">
              Instant Project Cost & Timeline Estimator
            </h3>
            <p className="text-xs text-slate-400">
              Get an approximate budgetary range for your industrial project scope.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Controls Column */}
        <div className="lg:col-span-7 space-y-4 text-xs">
          
          {/* Service Type */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5">
              Select Primary Service Discipline:
            </label>
            <select
              value={inputs.serviceType}
              onChange={(e) => setInputs({ ...inputs, serviceType: e.target.value })}
              className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500 font-medium"
            >
              <option value="industrial-fabrication">Industrial Fabrication (Tanks, Ducts, Structures)</option>
              <option value="structural-engineering">Structural Steel Works (Warehouses, Plant Framing)</option>
              <option value="cnc-machining">CNC Machining & Precision Parts</option>
              <option value="plant-maintenance">Plant Maintenance & Shutdown Overhaul</option>
              <option value="equipment-installation">Equipment Rigging & Machinery Erection</option>
            </select>
          </div>

          {/* Scale & Material Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-semibold mb-1.5">
                Project Scale / Scope:
              </label>
              <select
                value={inputs.projectScale}
                onChange={(e) => setInputs({ ...inputs, projectScale: e.target.value as any })}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500 font-medium"
              >
                <option value="small">Small Scope (&lt; 10 Tons / Prototype)</option>
                <option value="medium">Medium Scope (10 - 50 Tons / Standard)</option>
                <option value="large">Large Scope (50 - 200 Tons / Factory Unit)</option>
                <option value="heavy">Heavy Industrial (200+ Tons / Plant Expansion)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1.5">
                Material Grade:
              </label>
              <select
                value={inputs.materialGrade}
                onChange={(e) => setInputs({ ...inputs, materialGrade: e.target.value as any })}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded-xl p-3 focus:outline-none focus:border-amber-500 font-medium"
              >
                <option value="carbon_steel">Carbon Steel (IS 2062 / MS)</option>
                <option value="stainless_steel">Stainless Steel (304 / 316L)</option>
                <option value="alloy_steel">Special Alloy / Tool Steel</option>
              </select>
            </div>
          </div>

          {/* Urgency */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5">
              Project Timeline Urgency:
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setInputs({ ...inputs, urgency: 'standard' })}
                className={`py-2 px-3 rounded-lg border text-center transition-colors cursor-pointer ${
                  inputs.urgency === 'standard'
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                    : 'bg-slate-950 border-slate-700 text-slate-400'
                }`}
              >
                Standard
              </button>
              <button
                type="button"
                onClick={() => setInputs({ ...inputs, urgency: 'priority' })}
                className={`py-2 px-3 rounded-lg border text-center transition-colors cursor-pointer ${
                  inputs.urgency === 'priority'
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                    : 'bg-slate-950 border-slate-700 text-slate-400'
                }`}
              >
                Fast-Track
              </button>
              <button
                type="button"
                onClick={() => setInputs({ ...inputs, urgency: 'emergency' })}
                className={`py-2 px-3 rounded-lg border text-center transition-colors cursor-pointer ${
                  inputs.urgency === 'emergency'
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                    : 'bg-slate-950 border-slate-700 text-slate-400'
                }`}
              >
                Shutdown 24/7
              </button>
            </div>
          </div>

          {/* Toggles */}
          <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label className="flex items-center gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800 cursor-pointer text-slate-300">
              <input
                type="checkbox"
                checked={inputs.needsOnsiteInstallation}
                onChange={(e) => setInputs({ ...inputs, needsOnsiteInstallation: e.target.checked })}
                className="accent-amber-500 w-4 h-4"
              />
              <span>Includes Onsite Erection & Rigging</span>
            </label>

            <label className="flex items-center gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800 cursor-pointer text-slate-300">
              <input
                type="checkbox"
                checked={inputs.hasEngineeringDrawings}
                onChange={(e) => setInputs({ ...inputs, hasEngineeringDrawings: e.target.checked })}
                className="accent-amber-500 w-4 h-4"
              />
              <span>CAD Drawings Already Available</span>
            </label>
          </div>

        </div>

        {/* Results Column */}
        <div className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between space-y-6">
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
                Calculated Estimate
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded">
                Indicative Budget
              </span>
            </div>

            {/* Estimated Cost */}
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
              <div className="text-xs text-slate-400">Approximate Budgetary Range:</div>
              <div className="font-heading text-2xl sm:text-3xl font-black text-amber-400 flex items-center gap-1">
                <span>{formatRupees(result.estimatedCostMin)}</span>
                <span className="text-slate-500 text-lg font-light">–</span>
                <span>{formatRupees(result.estimatedCostMax)}</span>
              </div>
              <div className="text-[11px] text-slate-500">Excluding GST & local site levies</div>
            </div>

            {/* Estimated Duration & Team */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <div className="text-slate-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-amber-500" />
                  <span>Timeline</span>
                </div>
                <div className="text-lg font-bold text-white font-heading mt-1">
                  ~{result.estimatedDurationWeeks} Weeks
                </div>
              </div>

              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                <div className="text-slate-400 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-amber-500" />
                  <span>Site Team</span>
                </div>
                <div className="text-lg font-bold text-white font-heading mt-1">
                  ~{result.engineeringTeamSize} Engineers
                </div>
              </div>
            </div>

            {/* Inclusions */}
            <div className="space-y-1.5 pt-2">
              <div className="text-xs font-semibold text-slate-400">Included Services:</div>
              {result.recommendedServices.map((rec, i) => (
                <div key={i} className="flex items-center gap-2 text-xs text-slate-300">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  <span>{rec}</span>
                </div>
              ))}
            </div>

          </div>

          {/* Action Button */}
          <button
            onClick={handleApplyToContact}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold py-3.5 px-4 rounded-xl text-sm shadow-lg shadow-amber-500/20 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>Transfer Estimate To Quote Form</span>
          </button>

        </div>

      </div>

    </div>
  );
};
