import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ServicesSection } from './components/ServicesSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { AboutSection } from './components/AboutSection';
import { ProjectGallery } from './components/ProjectGallery';
import { QualitySafety } from './components/QualitySafety';
import { QuoteEstimator } from './components/QuoteEstimator';
import { ContactSection } from './components/ContactSection';
import { ServiceModal } from './components/ServiceModal';
import { ProjectModal } from './components/ProjectModal';
import { InquiryHistoryModal } from './components/InquiryHistoryModal';
import { Footer } from './components/Footer';

import { ServiceItem, ProjectItem, SubmittedInquiry } from './types';
import { Calculator, MessageSquare, Phone } from 'lucide-react';
import { companyDetails } from './data/companyData';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('home');
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  // Pre-fill parameters for Contact Form
  const [quoteServiceId, setQuoteServiceId] = useState<string>('industrial-fabrication');
  const [quoteBudgetText, setQuoteBudgetText] = useState<string>('');
  const [quoteMessageText, setQuoteMessageText] = useState<string>('');

  // Modals & Drawers
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [showEstimatorModal, setShowEstimatorModal] = useState<boolean>(false);

  // Inquiries stored in localStorage
  const [inquiries, setInquiries] = useState<SubmittedInquiry[]>(() => {
    try {
      const saved = localStorage.getItem('abc_inquiries');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('abc_inquiries', JSON.stringify(inquiries));
    } catch (e) {
      console.error("Failed to save inquiries to localStorage", e);
    }
  }, [inquiries]);

  // Navigation scroll helper
  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Inquire on specific service
  const handleInquireService = (serviceId: string) => {
    setQuoteServiceId(serviceId);
    handleNavigate('contact');
  };

  // Request similar project
  const handleRequestSimilarProject = (projectTitle: string) => {
    setQuoteServiceId('industrial-fabrication');
    setQuoteMessageText(`Requesting a project quote similar to: "${projectTitle}". Please provide a technical proposal and estimated timelines.`);
    handleNavigate('contact');
  };

  // Apply Cost Estimator calculation to contact form
  const handleApplyEstimate = (serviceId: string, budgetText: string, messageText: string) => {
    setQuoteServiceId(serviceId);
    setQuoteBudgetText(budgetText);
    setQuoteMessageText(messageText);
    setShowEstimatorModal(false);
    handleNavigate('contact');
  };

  // Handle new inquiry submission
  const handleInquirySubmitted = (newInquiry: SubmittedInquiry) => {
    setInquiries((prev) => [newInquiry, ...prev]);
  };

  const handleClearHistory = () => {
    setInquiries([]);
    localStorage.removeItem('abc_inquiries');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      
      {/* Sticky Navigation Bar */}
      <Navbar
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenHistory={() => setIsHistoryOpen(true)}
        inquiryCount={inquiries.length}
        onOpenEstimator={() => setShowEstimatorModal(true)}
      />

      {/* Main Page Layout */}
      <main className="flex-1">
        
        {/* Hero Section */}
        <HeroSection
          onNavigate={handleNavigate}
          onOpenEstimator={() => setShowEstimatorModal(true)}
        />

        {/* Services Section */}
        <ServicesSection
          onSelectService={(service) => setSelectedService(service)}
          onInquireService={handleInquireService}
        />

        {/* Why Choose Us */}
        <WhyChooseUs />

        {/* About Us Section */}
        <AboutSection />

        {/* Project Gallery & Case Studies */}
        <ProjectGallery
          onSelectProject={(project) => setSelectedProject(project)}
          onRequestSimilar={handleRequestSimilarProject}
        />

        {/* Quality & Safety Section */}
        <QualitySafety />

        {/* Embedded Estimator Banner Section */}
        <section className="py-16 bg-slate-950 border-t border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <QuoteEstimator onApplyEstimate={handleApplyEstimate} />
          </div>
        </section>

        {/* Contact Us & RFQ Form Section */}
        <ContactSection
          initialServiceId={quoteServiceId}
          initialBudgetText={quoteBudgetText}
          initialMessageText={quoteMessageText}
          onInquirySubmitted={handleInquirySubmitted}
        />

      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* Modals */}
      <ServiceModal
        service={selectedService}
        onClose={() => setSelectedService(null)}
        onInquire={handleInquireService}
      />

      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onRequestSimilar={handleRequestSimilarProject}
      />

      <InquiryHistoryModal
        inquiries={inquiries}
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onClear={handleClearHistory}
      />

      {/* Standalone Estimator Modal when launched from header or hero */}
      {showEstimatorModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="max-w-4xl w-full max-h-[90vh] overflow-y-auto rounded-3xl relative">
            <button
              onClick={() => setShowEstimatorModal(false)}
              className="absolute top-4 right-4 z-10 bg-slate-800 text-white p-2 rounded-full hover:bg-slate-700"
            >
              ✕
            </button>
            <QuoteEstimator onApplyEstimate={handleApplyEstimate} />
          </div>
        </div>
      )}

      {/* Floating Quick Action CTA */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-2">
        <a
          href={`tel:${companyDetails.phone}`}
          className="w-12 h-12 rounded-full bg-slate-900 border border-slate-700 text-amber-400 flex items-center justify-center shadow-2xl hover:scale-110 transition-transform cursor-pointer"
          title="Call Emergency Hotline"
        >
          <Phone className="w-5 h-5" />
        </a>

        <button
          onClick={() => handleNavigate('contact')}
          className="w-13 h-13 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold flex items-center justify-center shadow-2xl shadow-amber-500/30 hover:scale-110 transition-transform cursor-pointer"
          title="Quick Quote Request"
        >
          <MessageSquare className="w-6 h-6" />
        </button>
      </div>

    </div>
  );
}
