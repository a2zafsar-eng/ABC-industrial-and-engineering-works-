import {
  CompanyInfo,
  ServiceItem,
  ProjectItem,
  QualityStandard,
  WhyChooseUsItem,
} from '../types';

// Importing generated images
import heroImage from '../assets/images/hero_industrial_engineering_1786200841345.jpg';
import plantExpansionImg from '../assets/images/project_plant_expansion_1786200855124.jpg';
import cncMachiningImg from '../assets/images/project_cnc_machining_1786200870410.jpg';

export const companyDetails: CompanyInfo = {
  name: "ABC Industrial & Engineering Works",
  tagline: "Precision Engineering Solutions for Modern Industries",
  address: "Industrial Area, Bangalore, Karnataka, India",
  city: "Bangalore",
  state: "Karnataka",
  country: "India",
  phone: "+91 98765 43210",
  email: "info@abcengineering.com",
  website: "www.abcengineering.com",
  businessHours: "Monday – Saturday: 9:00 AM – 6:00 PM",
  establishedYear: 2008,
};

export const heroData = {
  headline: "Precision Engineering Solutions for Modern Industries",
  subheadline: "ABC Industrial & Engineering Works delivers high-performance industrial fabrication, structural steel, CNC machining, equipment installation, and comprehensive plant maintenance executed to international safety and quality standards.",
  bgImage: heroImage,
  stats: [
    { value: "15+", label: "Years Industry Experience" },
    { value: "500+", label: "Completed Heavy Projects" },
    { value: "100%", label: "ISO & Safety Compliance" },
    { value: "99.4%", label: "On-Time Project Delivery" },
  ],
};

export const aboutData = {
  overview: "ABC Industrial & Engineering Works was established to provide reliable engineering and industrial solutions for manufacturing plants, construction companies, power plants, and infrastructure projects.",
  mission: "To provide engineering excellence through skilled professionals, advanced technology, and a commitment to safety and quality.",
  vision: "To become a leading industrial engineering company recognized for quality, innovation, and customer satisfaction.",
  values: [
    { title: "Precision & Quality", desc: "Rigorous quality assurance and ISO-compliant procedures for all fabricated parts and assemblies." },
    { title: "Uncompromised Safety", desc: "Certified safety officers and mandatory zero-harm protocol across all workshop and field sites." },
    { title: "Engineering Innovation", desc: "Investing in advanced multi-axis CNC machinery, robotic welding, and modern CAD/CAM software." },
    { title: "Client Partnership", desc: "Transparent communication, milestone tracking, and competitive turn-key pricing." },
  ],
  sectorsServed: [
    { name: "Manufacturing & Heavy Assembly", desc: "Plant expansions, conveyor lines, heavy machine beds, and material handling systems." },
    { name: "Power Generation & Energy", desc: "Turbine maintenance, ducting, pressure piping, boiler structure repair, and balance of plant." },
    { name: "Oil & Gas / Chemical", desc: "Storage tanks, high-pressure piping, Skid-mounted process systems, and specialized alloy welding." },
    { name: "Commercial & Infrastructure", desc: "Warehouse structural steel framing, pre-engineered buildings, bridges, and industrial shelters." },
  ]
};

export const servicesData: ServiceItem[] = [
  {
    id: "industrial-fabrication",
    title: "Industrial Fabrication",
    shortDesc: "Custom fabrication of heavy steel structures, storage tanks, platforms, ducts, and industrial components.",
    fullDesc: "We specialize in heavy and light industrial fabrication tailored to exacting engineering specifications. Our facility is equipped with plate rolling, CNC plasma cutting, automatic submerged arc welding, and hydraulic press brakes to build robust industrial assemblies.",
    iconName: "Hammer",
    capabilities: [
      "Heavy structural steel beam & truss fabrication",
      "Storage tanks, silos, and pressure vessels",
      "Industrial ducting, chimneys, and exhaust stacks",
      "Custom hoppers, chutes, and material handling platforms"
    ],
    materials: ["Carbon Steel (IS 2062, A36)", "Stainless Steel (304, 316L)", "Alloy Steel", "Aluminum & Galvanized Sheets"],
    typicalApplications: ["Manufacturing Plants", "Cement & Mining Plants", "Refineries", "Infrastructure Work"],
    image: "https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&q=80&w=800",
    featured: true,
  },
  {
    id: "structural-engineering",
    title: "Structural Steel Works",
    shortDesc: "Design, shop fabrication, and site erection of structural steel framing for industrial facilities.",
    fullDesc: "Complete turn-key structural steel engineering for industrial warehouses, factory sheds, process towers, and commercial structures. From 3D Tekla modeling to field bolting and torque testing, we handle end-to-end execution.",
    iconName: "Building2",
    capabilities: [
      "3D CAD/CAM structural steel detailing",
      "Heavy column, rafter, and crane girder fabrication",
      "Pre-engineered building (PEB) component manufacturing",
      "Site alignment, bolting, and field erection supervision"
    ],
    materials: ["Structural Beams (I-Beams, H-Beams)", "Built-up Sections", "High-Tensile Bolts", "Roof Decking & Sheeting"],
    typicalApplications: ["Industrial Warehouses", "Factory Buildings", "Power Plant Structures", "Commercial Sheds"],
    image: plantExpansionImg,
    featured: true,
  },
  {
    id: "mechanical-engineering",
    title: "Mechanical Engineering Services",
    shortDesc: "Installation, precision alignment, maintenance, and overhaul of heavy industrial machinery.",
    fullDesc: "Our skilled mechanical engineers provide comprehensive field and workshop mechanical services. We handle precision laser alignment, gear box overhauls, hydraulic system piping, and pump assembly.",
    iconName: "Cog",
    capabilities: [
      "Laser shaft and optical machinery alignment",
      "Hydraulic & pneumatic system installation",
      "Heavy gearbox and drive motor overhauls",
      "Dynamic balancing of rotating equipment"
    ],
    materials: ["Precision Shafting", "Hardened Alloy Gears", "High-Pressure Hydraulic Tubing", "Bronze & Roller Bearings"],
    typicalApplications: ["Assembly Lines", "Processing Facilities", "Steel Rolling Mills", "Compressor Stations"],
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=800",
    featured: true,
  },
  {
    id: "cnc-machining",
    title: "CNC Machining & Manufacturing",
    shortDesc: "Precision machining for custom parts, shafts, flanges, dies, and high-tolerance industrial components.",
    fullDesc: "Utilizing advanced CNC vertical machining centers (VMC) and CNC turning lathes, we produce high-precision mechanical parts with tolerances down to ±0.005mm. Ideal for prototype development or bulk batch manufacturing.",
    iconName: "Cpu",
    capabilities: [
      "4-Axis CNC Milling & Precision VMC Machining",
      "Heavy-duty CNC Turning & Threading",
      "Custom gear cutting, splines, and keyways",
      "Coordinate Measuring Machine (CMM) quality inspection"
    ],
    materials: ["Stainless Steel (304, 316, 17-4PH)", "Tool Steels (D2, EN24, EN8)", "Brass, Bronze & Titanium"],
    typicalApplications: ["Automotive Assemblies", "Special Purpose Machines (SPM)", "Turbine Components", "Hydraulic Valves"],
    image: cncMachiningImg,
    featured: true,
  },
  {
    id: "welding-services",
    title: "Welding & Metal Fabrication",
    shortDesc: "MIG, TIG, Arc, and specialized code welding solutions for pressure piping and structural components.",
    fullDesc: "Our certified welders hold AWS / IS certifications for ASME Section IX welding procedures. We perform non-destructive testing (NDT) to ensure crack-free, high-integrity welds under extreme temperature and pressure conditions.",
    iconName: "Flame",
    capabilities: [
      "Gas Tungsten Arc Welding (TIG / GTAW) for SS & exotic alloys",
      "Gas Metal Arc Welding (MIG / GMAW) for rapid heavy plate jointing",
      "Shielded Metal Arc Welding (SMAW / Stick)",
      "Submerged Arc Welding (SAW) for long seam cylinder vessels"
    ],
    materials: ["Carbon Steels", "Austenitic & Duplex Stainless Steel", "Inconel & Hastelloy", "Structural Mild Steel"],
    typicalApplications: ["Oil & Gas Pipelines", "Pressure Piping Spools", "Heat Exchangers", "Boiler Pressure Parts"],
    image: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&q=80&w=800",
    featured: false,
  },
  {
    id: "plant-maintenance",
    title: "Plant Maintenance & Shutdowns",
    shortDesc: "Preventive, predictive, and turnaround emergency shutdown services for continuous plant operations.",
    fullDesc: "Minimize costly downtime with ABC's round-the-clock maintenance response team. We offer planned preventive maintenance schedules, annual maintenance contracts (AMC), and rapid turnaround shutdown support.",
    iconName: "Wrench",
    capabilities: [
      "Annual Maintenance Contracts (AMC) for industrial facilities",
      "Turnaround & emergency shutdown execution",
      "Vibration analysis and predictive maintenance",
      "Refractory lining, duct repair, and pipe replacement"
    ],
    materials: ["Wear-Resistant Liner Plates (Hardox)", "High-Temp Gaskets", "Insulation Jacketing", "Structural Spares"],
    typicalApplications: ["Chemical Processing", "Power Plants", "Cement Mills", "Food & Beverage Processing"],
    image: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&q=80&w=800",
    featured: false,
  },
  {
    id: "equipment-installation",
    title: "Equipment Installation & Rigging",
    shortDesc: "Turnkey rigging, heavy equipment positioning, foundation anchoring, and mechanical commissioning.",
    fullDesc: "Safe and precise positioning of heavy machinery up to 100+ tons. Our rigging engineers handle crane lifting plans, hydraulic jack systems, and precision leveling to ensure vibration-free equipment operation.",
    iconName: "Truck",
    capabilities: [
      "Heavy lift planning & engineered rigging design",
      "Grout injection and foundation anchor bolt alignment",
      "Overhead crane & monorail installation",
      "Cold & hot equipment commissioning"
    ],
    materials: ["High-Strength Non-Shrink Epoxies", "Vibration Isolation Pads", "Structural Rigging Shackles"],
    typicalApplications: ["Press Machine Installation", "Generator Set Erection", "Conveyor Network Rigging"],
    image: "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&q=80&w=800",
    featured: false,
  },
  {
    id: "project-management",
    title: "Industrial Project Management",
    shortDesc: "End-to-end engineering procurement, fabrication scheduling, quality auditing, and turn-key delivery.",
    fullDesc: "Dedicated engineering project managers assigned to streamline your project lifecycle. We utilize Primavera & MS Project scheduling to deliver turn-key industrial projects on time and strictly within budget.",
    iconName: "ClipboardCheck",
    capabilities: [
      "Detailed Procurement & Material Traceability Management",
      "Quality Assurance & NDT Test Record Archiving",
      "Site Safety Audit & Hazard Identification (HAZOP)",
      "Turnkey Subcontractor Coordination & Punch List Clearance"
    ],
    materials: ["Detailed Gantt Tracking", "ISO 9001:2015 Documentation", "MTR Material Test Certificates"],
    typicalApplications: ["Greenfield Industrial Plants", "Facility Modernization", "Capacity Expansion Projects"],
    image: "https://images.unsplash.com/photo-1541888946425-d0fbb186a5b3?auto=format&fit=crop&q=80&w=800",
    featured: false,
  }
];

export const projectsData: ProjectItem[] = [
  {
    id: "proj-1",
    title: "Manufacturing Plant Expansion",
    category: "fabrication",
    categoryName: "Industrial Fabrication & Erection",
    shortDesc: "Fabrication and installation of 450 metric tons of structural steel framing and process equipment platforms.",
    fullDesc: "Complete turn-key extension for a automotive components manufacturing plant in Bengaluru. The scope covered structural detailing, fabrication of 30-meter clear-span roof trusses, heavy crane girders, overhead monorails, and elevated operator platforms.",
    clientIndustry: "Automotive & Heavy Manufacturing",
    location: "Bangalore Industrial Corridor, Karnataka",
    completionYear: "2024",
    scopeOfWork: [
      "3D Tekla model detailing & shop drawing generation",
      "450 MT structural steel beam and column fabrication",
      "Submerged Arc Welding for heavy box girders",
      "High-durability epoxy primer & polyurethane topcoat painting",
      "Precision site erection with 100-ton hydraulic cranes"
    ],
    keyDeliverables: [
      "Completed 18 days ahead of schedule",
      "Zero lost-time incidents across 45,000 man-hours",
      "100% NDT inspection pass rate on structural welds"
    ],
    image: plantExpansionImg,
    stats: [
      { label: "Steel Fabricated", value: "450 Tons" },
      { label: "Duration", value: "4.5 Months" },
      { label: "Safety Score", value: "100% Zero Harm" }
    ]
  },
  {
    id: "proj-2",
    title: "Industrial Warehouse Construction",
    category: "structural",
    categoryName: "Structural Engineering",
    shortDesc: "Complete engineering, structural steel framing, and roofing for a 120,000 sq. ft. logistics warehouse facility.",
    fullDesc: "Engineering, shop fabrication, and site construction of a modern pre-engineered logistics warehouse. Featured high-eave clearances, crane runways, dock leveler pits, and insulated standing-seam roofing panels.",
    clientIndustry: "Logistics & Supply Chain Infrastructure",
    location: "Hosur Road Industrial Belt, Karnataka",
    completionYear: "2023",
    scopeOfWork: [
      "Foundation bolt layout and civil anchor alignment",
      "Fabrication of tapered plate columns and rafter rafters",
      "Galvanized Z & C purlins installation",
      "Standing-seam roof sheathing & continuous Ridge ventilator installation",
      "Turnkey lighting & crane girder bracket integration"
    ],
    keyDeliverables: [
      "120,000 Sq. Ft. clear-span usable floor space",
      "Designed for 150 km/h wind load resistance",
      "Full ISO 9001 quality compliance certificate"
    ],
    image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=800",
    stats: [
      { label: "Facility Area", value: "120,000 Sq.Ft." },
      { label: "Eave Height", value: "12 Meters" },
      { label: "Clear Span", value: "36 Meters" }
    ]
  },
  {
    id: "proj-3",
    title: "Power Plant Mechanical Maintenance",
    category: "maintenance",
    categoryName: "Plant Maintenance & Overhaul",
    shortDesc: "Comprehensive mechanical overhaul, ducting repair, and equipment refurbishment during annual shutdown.",
    fullDesc: "Turnkey mechanical maintenance during a critical 14-day plant shutdown at a thermal power facility. Replaced worn boiler ducting, refurbished heavy induced-draft (ID) fans, overhauled high-pressure valves, and re-aligned drive shafts.",
    clientIndustry: "Power Generation & Energy",
    location: "Bellary, Karnataka",
    completionYear: "2024",
    scopeOfWork: [
      "Demolition and replacement of 60 meters damaged flue gas ducting",
      "In-situ dynamic balancing of 2.4m diameter ID fan impellers",
      "Laser shaft alignment for 1200 kW motor-pump sets",
      "Refractory lining repairs & thermal insulation jacketing"
    ],
    keyDeliverables: [
      "Completed 12 hours ahead of strict grid restart deadline",
      "Reduced fan vibration by 68% following precision balancing",
      "Post-repair pressure testing passed on first attempt"
    ],
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=800",
    stats: [
      { label: "Shutdown Window", value: "14 Days" },
      { label: "Team Size", value: "65 Specialists" },
      { label: "Vibration Cut", value: "-68%" }
    ]
  },
  {
    id: "proj-4",
    title: "Oil & Gas Facility Support & Piping",
    category: "oilgas",
    categoryName: "Oil & Gas / Heavy Industrial",
    shortDesc: "High-pressure stainless steel pipeline fabrication, 100% X-ray certified welding, and pressure vessel skids.",
    fullDesc: "Fabrication and installation of process piping spools and Skid-mounted fluid metering modules for a chemical & hydrocarbon processing terminal. Rigorous ASME B31.3 code compliance and 100% Radiographic Testing (RT).",
    clientIndustry: "Oil, Gas & Chemical Processing",
    location: "Mangalore Port Zone, Karnataka",
    completionYear: "2023",
    scopeOfWork: [
      "316L Stainless steel Schedule 40 & 80 pipe spool fabrication",
      "TIG root pass welding with purging gas control",
      "Hydrostatic testing at 1.5x design operating pressure (120 Bar)",
      "Pickling & passivation surface treatment",
      "Modular Skid frame fabrication and structural galvanizing"
    ],
    keyDeliverables: [
      "Zero weld defects across 820 joint RT films",
      "ASME Code stamp compliance verification",
      "Containerized modular delivery for instant site hookup"
    ],
    image: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&q=80&w=800",
    stats: [
      { label: "Joints Tested", value: "820 Welds" },
      { label: "Hydro Test", value: "120 Bar" },
      { label: "Weld Defect Rate", value: "0.00%" }
    ]
  },
  {
    id: "proj-5",
    title: "Precision CNC Machine Tooling & Components",
    category: "fabrication",
    categoryName: "CNC Machining & Manufacturing",
    shortDesc: "Batch production of high-tolerance alloy steel shafting, custom flanges, and heavy hydraulic cylinders.",
    fullDesc: "Ongoing precision manufacturing contract for special purpose machinery builder. Components machined on 4-axis VMCs with strict surface finish requirements (Ra 0.4 µm) and tight CMM quality reports.",
    clientIndustry: "Special Purpose Machine (SPM) OEMs",
    location: "Peenya Industrial Area, Bangalore",
    completionYear: "2024",
    scopeOfWork: [
      "CNC turning & precision grinding of EN24 hardened shafts",
      "VMC 4th-axis helical groove machining",
      "Induction hardening & black oxide protective coating",
      "100% CMM dimensional inspection reporting per batch"
    ],
    keyDeliverables: [
      "Over 12,000 precision parts delivered with zero reject rate",
      "Kanban inventory management for quick client dispatch",
      "Traceable heat code certificates provided"
    ],
    image: cncMachiningImg,
    stats: [
      { label: "Parts Produced", value: "12,000+" },
      { label: "Tolerance", value: "±0.005mm" },
      { label: "Reject Rate", value: "0%" }
    ]
  },
  {
    id: "proj-6",
    title: "Heavy Machinery Erection & Foundation",
    category: "maintenance",
    categoryName: "Equipment Installation",
    shortDesc: "Turnkey rigging, leveling, and foundation anchoring of 80-ton stamping presses and continuous line equipment.",
    fullDesc: "Heavy equipment rigging and precision installation for a sheet metal stamping facility. Included soil-isolated concrete foundation anchoring, vibration damper mounting, and laser leveling.",
    clientIndustry: "Heavy Sheet Metal Stamping",
    location: "Bidadi Industrial Area, Karnataka",
    completionYear: "2023",
    scopeOfWork: [
      "Hydraulic gantry crane deployment for 80-ton press lift",
      "High-precision optical leveling and alignment within 0.05mm/m",
      "Non-shrink epoxy grout injection beneath machine bedplates",
      "Hydraulic & pneumatic pipe connections and system flushing"
    ],
    keyDeliverables: [
      "Successfully installed without interruption to adjacent operational lines",
      "Vibration isolation test passed full stamping load",
      "Turnkey handover within 10 days"
    ],
    image: "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&q=80&w=800",
    stats: [
      { label: "Max Single Lift", value: "80 Tons" },
      { label: "Leveling Precision", value: "0.05mm/m" },
      { label: "Turnaround", value: "10 Days" }
    ]
  }
];

export const whyChooseUsData: WhyChooseUsItem[] = [
  {
    id: "team",
    title: "Experienced Engineering Team",
    description: "Multi-disciplinary team of certified mechanical engineers, Tekla detailers, AWS welders, and safety managers with decades of hands-on industrial expertise.",
    metric: "15+",
    metricLabel: "Years Average Experience",
    iconName: "Users"
  },
  {
    id: "quality",
    title: "Quality Assurance",
    description: "Strict quality control procedures at every stage — raw material mill test certificates, dimension checks, NDT weld inspections, and surface coating DFT audits.",
    metric: "ISO",
    metricLabel: "9001:2015 Compliant",
    iconName: "ShieldCheck"
  },
  {
    id: "timely",
    title: "Timely Project Delivery",
    description: "Resource-loaded project schedules, off-site pre-fabrication, and round-the-clock site teams ensure milestone completion strictly on time.",
    metric: "99.4%",
    metricLabel: "On-Time Completion Rate",
    iconName: "Clock"
  },
  {
    id: "pricing",
    title: "Competitive Pricing",
    description: "Direct material sourcing, optimized shop floor productivity, and transparent bill of quantities (BOQ) deliver maximum value without compromising quality.",
    metric: "100%",
    metricLabel: "Transparent Quotations",
    iconName: "BadgeIndianRupee"
  },
  {
    id: "technology",
    title: "Advanced Machinery & Technology",
    description: "Modern facility featuring 4-axis CNC machine tools, CNC plasma plate cutters, submerged arc welding gantries, and 3D Tekla CAD design software.",
    metric: "CNC",
    metricLabel: "Precision Tech Stack",
    iconName: "Cpu"
  },
  {
    id: "safety",
    title: "Strong Safety Standards",
    description: "Comprehensive EHS policy, daily toolbox safety talks, mandatory PPE enforcement, and certified rigging & height safety protocols.",
    metric: "0",
    metricLabel: "Lost-Time Accidents Record",
    iconName: "HardHat"
  }
];

export const qualityStandardsData: QualityStandard[] = [
  {
    id: "iso",
    title: "ISO-Compliant Quality Management",
    description: "Integrated Quality Management System governing material procurement, fabrication tolerances, and final dispatch procedures.",
    iconName: "Award",
    highlights: [
      "100% Traceable Raw Material Mill Test Reports (MTR)",
      "Standardized Welding Procedure Specifications (WPS & PQR)",
      "Calibrated measuring instruments & CMM reporting",
      "Final pre-dispatch dimensional and paint thickness audit"
    ]
  },
  {
    id: "certified-welders",
    title: "Certified Welders & Technicians",
    description: "Welding operators qualified under ASME Section IX, IS 7307, and AWS D1.1 structural welding standards.",
    iconName: "Flame",
    highlights: [
      "Qualified for SMAW, GMAW, GTAW, and SAW processes",
      "6G pipe welding certification for pressure lines",
      "Regular re-qualification audits and weld log archiving"
    ]
  },
  {
    id: "safety-training",
    title: "Safety Training & EHS Protocols",
    description: "Zero-accident philosophy enforced through rigorous Environmental, Health, and Safety (EHS) guidelines.",
    iconName: "ShieldAlert",
    highlights: [
      "Daily pre-shift Safety Toolbox Talks at all job sites",
      "Certified scaffolding inspectors and crane riggers",
      "Work-at-height and confined space entry permits",
      "Complete personal protective equipment (PPE) compliance"
    ]
  },
  {
    id: "ndt-testing",
    title: "Quality Inspection & NDT Testing",
    description: "In-house and third-party Non-Destructive Testing (NDT) to ensure structural integrity and leak-proof welds.",
    iconName: "Microscope",
    highlights: [
      "Ultrasonic Testing (UT) for heavy plate laminations & welds",
      "Radiographic Testing (RT / X-ray) for pressure piping spools",
      "Magnetic Particle Testing (MPT) & Dye Penetrant Testing (DPT)",
      "Hydrostatic testing up to 250 Bar and pneumatic leak checks"
    ]
  },
  {
    id: "environmental",
    title: "Environmental Responsibility",
    description: "Sustainable workshop operations with eco-friendly waste disposal, low-VOC coatings, and energy-efficient machinery.",
    iconName: "Leaf",
    highlights: [
      "Fume extraction and air filtration in welding bays",
      "Steel scrap recycling and hazardous waste management",
      "Low-VOC industrial painting procedures"
    ]
  }
];

export const faqData = [
  {
    q: "What types of industrial projects do you specialize in?",
    a: "We specialize in heavy structural steel fabrication, plant expansions, CNC precision machining, equipment installation, pressure vessel & storage tank fabrication, piping spools, and annual plant maintenance shutdowns across India."
  },
  {
    q: "Where is ABC Industrial & Engineering Works located?",
    a: "Our primary office and fabrication workshop are located in the Industrial Area, Bangalore, Karnataka, India. We execute field projects and site installation across Karnataka and surrounding industrial hubs."
  },
  {
    q: "Do you provide turnkey engineering and site installation?",
    a: "Yes! We offer end-to-end turnkey services — from 3D CAD detailing and raw material procurement to shop fabrication, surface coating, transportation, and field site erection."
  },
  {
    q: "What quality certifications and weld testing standards do you follow?",
    a: "We strictly follow ISO 9001 procedures, ASME Section IX, AWS D1.1 structural codes, and IS 2062 material standards. We perform Ultrasonic (UT), Radiographic (RT), Magnetic Particle (MPT), Dye Penetrant (DPT), and Hydrostatic testing."
  },
  {
    q: "How can I request a formal quotation or cost estimate?",
    a: "You can submit your project requirements using our online Contact & Quote Request Form, use our Instant Estimator Tool, or directly call us at +91 98765 43210 or email info@abcengineering.com."
  }
];
